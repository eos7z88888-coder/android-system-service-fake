WARNING - LIVE MALWARE
For security research and defensive analysis only. Do not install.

Package: com.servers.ozzbzk
IPC: content://com.servers.ozzbzk.bridge

警告 - 真实恶意软件
仅用于安全研究与防御分析，禁止安装。
