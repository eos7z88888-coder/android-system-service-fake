MALWARE QUARANTINE — DO NOT INSTALL OR EXECUTE ON ANY DEVICE
================================================================

Package:  com.servers.ozzbzk
Label:    System Service (fake)
Type:     Android bridge backdoor (BridgeProvider IPC)

Files:
  system_service_ORIGINAL_MALWARE.apk     — Original sample from investigation (SHA256 below)
  system_service_HONEYPOT_VARIANT.apk     — Patched receive-only honeypot (was on phone)
  attribution_REPORT.md                 — Analysis summary
  SHA256SUMS.txt                          — Hashes

Original APK SHA256:
  b693855c1e36cca582284f7f4582a3296ec5df4b4b8edfbfb4a085747feade4d

Honeypot (on-device) SHA256:
  82a32cada3bfd073f35c6fa0251eaf31b055565b282cc02b50cac73355a1ec38

Authority: content://com.servers.ozzbzk.bridge

Sealed: 2026-10-04
Phone copies uninstalled per user request.
